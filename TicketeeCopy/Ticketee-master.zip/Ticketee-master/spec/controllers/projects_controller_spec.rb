require 'rails_helper'

RSpec.describe ProjectsController, type: :controller do

end
